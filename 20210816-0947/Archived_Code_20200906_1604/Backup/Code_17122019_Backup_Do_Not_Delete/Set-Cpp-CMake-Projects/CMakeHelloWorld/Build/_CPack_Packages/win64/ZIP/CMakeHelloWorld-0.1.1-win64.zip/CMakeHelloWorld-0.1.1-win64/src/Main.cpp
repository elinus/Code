#include <iostream>

int main(int argc, char* argv[]) {
	
	std::cout << "CMake Hello World!!" << std::endl;
	/*
	if (argc > 1) return 1;
	*/
	return 0;
}